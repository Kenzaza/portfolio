<?php

include '../database/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $userName = $_POST['userName'];
    $userPassword = $_POST['userPassword'];

    $sql = "SELECT * FROM user WHERE userName = '${userName}' AND userPassword = '${userPassword}' ";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $result2 = mysqli_fetch_assoc($result);

        $_SESSION['loggedIn'] = true;
        $_SESSION['userName'] = $userName;
        $_SESSION['userId'] = $result2['userId'];

?> <script>
            alert("Login Success")
        </script>
        <?php
        header("refresh:0;url=../index.php");
        ?>
<?php


    }
}

?>