<?php

include '../database/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $userName = $_POST['userName'];
    $userEmail = $_POST['userEmail'];
    $userPassword = $_POST['userPassword'];

    $sql = "INSERT INTO user (userName, userEmail, userPassword) VALUES ('${userName}','${userEmail}','${userPassword}')";

    if (mysqli_query($conn, $sql)) {
?> <script>
            alert("Register Success Go to Login -->")
        </script>
        <?php
        header("refresh:0;url=../login.php");
        ?>
<?php
    }
}

?>