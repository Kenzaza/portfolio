<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "bookstore";

$conn = mysqli_connect($hostname, $username, $password, $database);

if(!$conn){
    echo mysqli_connect_error();
}
?>