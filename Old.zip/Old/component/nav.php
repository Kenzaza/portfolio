<div class="container d-flex justify-content-center">
    <a class="btn btn-primary mx-2 shadow-lg" href="../index.php" type="button">Home</a>
    <?php
    if (isset($_SESSION['loggedIn']) == false || $_SESSION['loggedIn'] == false) { ?>
        <a class="btn btn-primary mx-2 shadow-lg" href="../login.php" type="button">Login</a>
        <a class="btn btn-primary mx-2 shadow-lg" href="../register.php" type="button">Register</a>
    <?php
    } else { ?>
        <p class="fs-4">User: <?php echo $_SESSION['userName']; ?></p>
        <a class="btn btn-danger mx-2 shadow-lg" href="../logout.php" type="button">Logout</a>
    <?php
    }
    ?>
</div>