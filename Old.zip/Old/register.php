<?php
include './database/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
</head>

<body>
    <div class="container bg-primary rounded shadow-lg  ">
        <p class="fs-1 my-5 py-3 text-center text-white">Book Shop | Register</p>
    </div>
    <!-- nav -->
    <?php
    include './component/nav.php';
    ?>
    <br>
    <div class="container">
        <hr>
    </div>
    <br>

    <div class="container">
        <form action="./action/addUser.php" method="POST">
            <label class="form-label">Username : </label>
            <input class="form-control" type="text" name="userName" require><br>
            <label class="form-label">Email : </label>
            <input class="form-control" type="email" name="userEmail" require><br>
            <label class="form-label">Password : </label>
            <input class="form-control" type="password" name="userPassword" require><br>
            <button class="btn btn-primary" type="submit">Register</button>
        </form>
    </div>

    <script src="./assets/js/bootstrap.min.js"></script>
</body>

</html>